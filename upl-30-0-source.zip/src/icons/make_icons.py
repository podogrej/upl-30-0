# Генерує icons.js: SVG-іконки (Material Design Icons + 2 бренди Font Awesome) для інтерфейсу (стиль C — іконка в помаранчевій плитці)
# і значки трофеїв (T3 — шестикутник). Іконки вбудовуються в сторінку, нічого не вантажиться зі сторонніх сайтів.
import re, json
ROOT='/usr/local/lib/python3.11/dist-packages/material/templates/.icons'
UI=['trophy','fire','snowflake','sword-cross','calendar-star','ferris-wheel','soccer-field','format-list-numbered','share-variant','send',
    'account-circle','bullhorn','lock-open-variant','chart-bar','incognito','eye','check-circle','check-decagram','handshake','content-copy','image',
    'star','lock','google','star-four-points','account-group','new-box','chart-box','medal','crown']
TR={ # трофей → гліф
 'champ':'trophy','top3':'star','unbeaten':'shield-star','perfect':'diamond-stone','mid8':'scale-balance','relegated':'trending-down',
 'goals80':'soccer','fortress':'wall','iron':'door-closed-lock','nodraw':'sword-cross','sieve':'dots-grid','lucky':'clover','unlucky':'weather-pouring',
 'allua':'flag-variant','nations':'earth','band7':'stadium-variant','band5':'account-group','abc':'alphabetical-variant','tannoy':'bullhorn',
 'pegs':'swap-horizontal','vets':'human-cane','striker':'target','assist':'magic-staff','eight':'star-shooting','hardchamp':'fire','hcchamp':'eye-off',
 'derbychamp':'lightning-bolt','oneclubchamp':'heart','antilast':'arrow-down-bold','anti0':'grave-stone','antidry':'bread-slice','dchamp':'calendar-star',
 's3':'fire','s7':'calendar-week','s14':'calendar-month','s30':'calendar-check','d10':'coffee','d50':'medal','golden':'trophy-variant','rebsh':'handshake',
 'samba':'music','noua':'airplane','namesakes':'card-account-details','ghosts':'ghost','crimea':'waves','cross':'road-variant','mediocre':'hat-fedora',
 'cursed':'crystal-ball','heist':'sack','fairy':'auto-fix','fallen':'star-off','kids':'baby-face-outline','gkmvp':'hand-back-right','bottom':'chevron-triple-down',
 'ms1':'sprout','ms5':'soccer','ms10':'ticket','ms25':'ribbon','ms50':'medal','ms100':'star-circle','ms250':'bank'}
def load(path):
    t=open(path).read();vb=re.search(r'viewBox="([^"]+)"',t).group(1);ds=re.findall(r'<path[^>]*\sd="([^"]+)"',t)
    assert len(ds)==1,(path,len(ds));return [vb,ds[0]]
ICO={}
for n in sorted(set(UI)|set(TR.values())):ICO[n]=load(f'{ROOT}/material/{n}.svg')
ICO['telegram']=load(f'{ROOT}/fontawesome/brands/telegram.svg')
# у трофеях кожен id з гри має отримати гліф
ids=re.findall(r'\{id:"([a-z0-9]+)"',open('/home/claude/upl-dataset/game/trophies.js').read())
miss=[i for i in ids if i not in TR];assert not miss,miss
js=f'''// ЗГЕНЕРОВАНО icons/make_icons.py — не редагувати вручну.
// Іконки: Material Design Icons (Pictogrammers, Apache-2.0) і логотип Telegram з Font Awesome Free (CC BY 4.0).
const ICO={json.dumps(ICO,separators=(',',':'))};
function icon(n){{const x=ICO[n];return x?`<svg class="ico" viewBox="${{x[0]}}" aria-hidden="true"><path d="${{x[1]}}"/></svg>`:'';}}
function ic(n,cls){{return `<i class="ic${{cls?' '+cls:''}}">${{icon(n)}}</i>`;}}   // стиль C: іконка в помаранчевій плитці
const TR_GLYPH={json.dumps(TR,separators=(',',':'))};
const TR_COL={{season:'var(--gk)',squad:'var(--mf)',players:'var(--amber)',modes:'var(--fw)',daily:'var(--df)',secret:'#a77ee6',milestone:'var(--gk)'}};
const HEX_D='M50 3 L91 26.5 V73.5 L50 97 L9 73.5 V26.5 Z';
// значок трофея (T3): шестикутник кольору категорії, гліф усередині; закритий — сірий із замком
function trBadge(t,got){{const g=ICO[TR_GLYPH[t.id]]||ICO.trophy;const l=ICO.lock;
  return `<svg class="hx${{got?'':' off'}}" viewBox="0 0 100 100" style="--c:${{got?(TR_COL[t.cat]||'var(--amber)'):'var(--muted)'}}" aria-hidden="true"><path class="o" d="${{HEX_D}}"/><path class="in" d="${{HEX_D}}" transform="translate(50 50) scale(.84) translate(-50 -50)"/><svg x="29" y="29" width="42" height="42" viewBox="${{g[0]}}"><path class="g" d="${{g[1]}}"/></svg>`+
    (got?'':`<circle class="lk" cx="80" cy="80" r="15"/><svg x="71" y="71" width="18" height="18" viewBox="${{l[0]}}"><path class="lg" d="${{l[1]}}"/></svg>`)+'</svg>';}}
'''
open('/home/claude/upl-dataset/game/icons.js','w').write(js)
print(len(ICO),'icons',len(js),'bytes')
